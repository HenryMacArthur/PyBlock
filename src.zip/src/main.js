// main.js
import * as Blockly from 'blockly/core';
import 'blockly/blocks';
import 'blockly/msg/en';
// that provides the words for the blocks. This one is for English. Without it, we would get blank blocks.
import './blocks/index.js';
// Index.js is what gathers all the block categories and sends them to this
import { toolbox } from './toolbox.js';
// Toolbox is what the sidebar with the blocks will look like.
import { pybricksGenerator } from './generator.js';




const workspace = Blockly.inject(document.querySelector('.blocklyDiv'), {
    toolbox,
    grid: {
        spacing: 20,
        length: 3,
        colour: '#ccc',
        snap: true,
    },
    zoom: {
        controls: true,
        wheel: true,
        startScale: 1.0,
        maxScale: 3,
        minScale: 0.3,
        scaleSpeed: 1.2,
    },
    trashcan: true,
    theme: Blockly.Themes.Classic,
});

window.addEventListener('resize', () => {
    Blockly.svgResize(workspace);
});


document.getElementById('generateBtn').addEventListener('click', () => {
    const code = pybricksGenerator.workspaceToCode(workspace);
    const tab = window.open('', '_blank');
    tab.document.open();
    tab.document.write(`<pre>${code}</pre>`);
    tab.document.close();
});
// Currently that doesn't do anything if there's no code in the workspace,
// So we should probably make it do something, like give you Python that looks like # No code yet
// Or give you an alert